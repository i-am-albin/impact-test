<?php 

use Illuminate\Support\Facades\Auth;

function country_list(){

return $counties = array(
		'England' => array(
		array(
			'value' =>'Avon'),
		array(
			'value' =>'Bedfordshire'),		
		array(
			'value' =>'Berkshire'),
		array(
			'value' =>'Buckinghamshire'),		
		array(
			'value' =>
			'Cambridgeshire'),		
		array(
			'value' =>
			'Cheshire'),		
		array(
			'value' =>
			'Cleveland'),		
		array(
			'value' =>
			'Cornwall'),		
		array(
			'value' =>
			'Cumbria'),		
		array(
			'value' =>
			'Derbyshire'),		
		array(
			'value' =>
			'Devon'),		
		array(
			'value' =>
			'Dorset'),		
		array(
			'value' =>
			'Durham'),		
		array(
			'value' =>
			'East Sussex'),		
		array(
			'value' =>
			'Essex'),		
		array(
			'value' =>
			'Gloucestershire'),		
		array(
			'value' =>
			'Hampshire'),		
		array(
			'value' =>
			'Herefordshire'),		
		array(
			'value' =>
			'Hertfordshire'),		
		array(
			'value' =>
			'Isle of Wight'),		
		array(
			'value' =>
			'Kent'),		
		array(
			'value' =>
			'Lancashire'),		
		array(
			'value' =>
			'Leicestershire'),		
		array(
			'value' =>
			'Lincolnshire'),		
		array(
			'value' =>
			'London'),		
		array(
			'value' =>
			'Merseyside'),		
		array(
			'value' =>
			'Middlesex'),		
		array(
			'value' =>
			'Norfolk'),		
		array(
			'value' =>
			'Northamptonshire'),		
		array(
			'value' =>
			'Northumberland'),		
		array(
			'value' =>
			'North Humberside'),		
		array(
			'value' =>
			'North Yorkshire'),		
		array(
			'value' =>
			'Nottinghamshire'),		
		array(
			'value' =>
			'Oxfordshire'),		
		array(
			'value' =>
			'Rutland'),		
		array(
			'value' =>
			'Shropshire'),		
		array(
			'value' =>
			'Somerset'),		
		array(
			'value' =>
			'South Humberside'),		
		array(
			'value' =>
			'South Yorkshire'),		
		array(
			'value' =>
			'Staffordshire'),		
		array(
			'value' =>
			'Suffolk'),		
		array(
			'value' =>
			'Surrey'),		
		array(
			'value' =>
			'Tyne and Wear'),		
		array(
			'value' =>
			'Warwickshire'),		
		array(
			'value' =>
			'West Midlands'),		
		array(
			'value' =>
			'West Sussex'),		
		array(
			'value' =>
			'West Yorkshire'),		
		array(
			'value' =>
			'Wiltshire'),		
		array(
			'value' =>
			'Worcestershire'		
			)),
		'Wales' => array(
		array(
			'value' =>'Clwyd'),
		array(
			'value' =>	'Dyfed'),
		array(
			'value' =>'Gwent'),
		array(
			'value' =>'Gwynedd'),
		array(
			'value' =>'Mid Glamorgan'),
		array(
			'value' =>'Powys'),
		array(
			'value' =>'South Glamorgan'),
		array(
			'value' =>'West Glamorgan'),
		),
		'Scotland' => array(
		array(
			'value' =>'Aberdeenshire'),
		array(
			'value' =>'Angus'),
		array(
			'value' =>'Argyll'),
		array(
			'value' =>'Ayrshire'),
		array(
			'value' =>'Banffshire'),
		array(
			'value' =>'Berwickshire'),
		array(
			'value' =>'Bute'),
		array(
			'value' =>'Caithness'),
		array(
			'value' =>'Clackmannanshire'),
		array(
			'value' =>'Dumfriesshire'),
		array(
			'value' =>'Dunbartonshire'),
		array(
			'value' =>'East Lothian'),
		array(
			'value' =>'Fife'),
		array(
			'value' =>'Inverness-shire'),    
		array(
			'value' =>'Kincardineshire'),
		array(
			'value' =>'Kinross-shire'),
		array(
			'value' =>'Kirkcudbrightshire'),
		array(
			'value' =>'Lanarkshire'),
		array(
			'value' =>'Midlothian'),
		array(
			'value' =>'Moray'),
		array(
			'value' =>'Nairnshire'),
		array(
			'value' =>'Orkney'),
		array(
			'value' =>'Peeblesshire'),
		array(
			'value' =>'Perthshire'),
		array(
			'value' =>'Renfrewshire'),
		array(
			'value' =>'Ross-shire'),
		array(
			'value' =>'Roxburghshire'),
		array(
			'value' =>'Selkirkshire'),
		array(
			'value' =>'Shetland'),
		array(
			'value' =>'Stirlingshire',
			'Sutherland'),
		array(
			'value' =>'West Lothian'),
		array(
			'value' =>'Wigtownshire'
		)),
		'Northern Ireland' => array(
			array(
			'value' =>'Antrim'),
			array(
			'value' =>'Armagh'),
			array(
			'value' =>'Down'),
			array(
			'value' =>'Fermanagh'),
			array(
			'value' =>'Londonderry'),
			array(
			'value' =>'Tyrone')
		)
);
}