<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body" style="height: 300px;">

                    <?php if(Auth::user()): ?>
                         <select class="form-control select2" id="county" onchange="getCities()">
                                        
                                <option disabled selected>Select</option>    
                                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($key); ?></option>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                         </select>
                    <?php endif; ?>

                    <div id="citiesDiv" style="display: none;margin-top: 50px;">
                        
                    <select class="form-control select2" id="cities">                        
                    </select>    
                    <br><br>                    
                    <button style="form-control" onClick="getWeather()">Get Data</button>
                    <br><br>
                    <div class="jumbotron" style="display: none;" >
                        <div class="row w-100">
                                <div class="col-md-3">
                                    <div class="card border-info mx-sm-1 p-3">
                                        <div class="card border-info shadow text-info p-3 my-card" ><span class="fa fa-car" aria-hidden="true"></span></div>
                                        <div class="text-info text-center mt-3"><h4>Day</h4></div>
                                        <div class="text-info text-center mt-2"><h5><span id="day"></span></h5></div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="card border-success mx-sm-1 p-3">
                                        <div class="card border-success shadow text-success p-3 my-card"><span class="fa fa-eye" aria-hidden="true"></span></div>
                                        <div class="text-success text-center mt-3"><h4>Night</h4></div>
                                        <div class="text-success text-center mt-2"><h5><span id="night"></span></div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="card border-danger mx-sm-1 p-3">
                                        <div class="card border-danger shadow text-danger p-3 my-card" ><span class="fa fa-heart" aria-hidden="true"></span></div>
                                        <div class="text-danger text-center mt-3"><h4>Evening</h4></div>
                                        <div class="text-danger text-center mt-2"><h5><span id="eve"></span></div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="card border-warning mx-sm-1 p-3">
                                        <div class="card border-warning shadow text-warning p-3 my-card" ><span class="fa fa-inbox" aria-hidden="true"></span></div>
                                        <div class="text-warning text-center mt-3"><h4>Morning</h4></div>
                                        <div class="text-warning text-center mt-2"><h5><span id="mor"></span></div>
                                    </div>
                                </div>
                         </div>
                    </div>                    
                    </div>
                        
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<script type="text/javascript">
    
       
    function getCities() {
        
        var county = $("#county").val();
        $.ajax({
            type: 'POST',
            url: "<?php echo e(url('/get-cities')); ?>",
            data: {county : county,"_token": "<?php echo e(csrf_token()); ?>" },
            dataType: 'json',
            success: function (data) {
               
               $("#cities").empty();
                $.each(data, function (i, item) {

                    

                    $('#cities').append($('<option>', { 
                         value: item.value,
                         text : item.value 
                    }));
                });

                $("#citiesDiv").show();

            },
            error: function (data) {
                
                alert("Try Another Cities")
            }
        });
    }

    function getWeather() {
       
       var county = $("#county").val();
       var cities = $("#cities").val();
        
        $.ajax({
            type: 'POST',
            url: "<?php echo e(url('/get-weather')); ?>",
            data: {county : county,cities:cities,"_token": "<?php echo e(csrf_token()); ?>"},
            dataType: 'json',
            success: function (data) {
                    console.log(data.data.city);
                    var today = new Date();
                    var day =today.getDay();
                    $("#day").text(data.data.list[day].feels_like.day+' C');
                    $("#night").text(data.data.list[day].feels_like.night+' C');
                    $("#mor").text(data.data.list[day].feels_like.morn+' C');
                    $("#eve").text(data.data.list[day].feels_like.eve+' C');
                    $(".jumbotron").show();

            },
            error: function (data) {
                console.log(data);
            }
        });       

    }
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\test\resources\views/home.blade.php ENDPATH**/ ?>